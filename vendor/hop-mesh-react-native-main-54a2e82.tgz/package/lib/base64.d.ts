/** Encode raw bytes as a standard (padded) base64 string. */
export declare function toBase64(bytes: Uint8Array): string;
/** Decode a base64 string back to raw bytes. Rejects characters outside the alphabet. */
export declare function fromBase64(text: string): Uint8Array;
/** Encode a UTF-8 string as bytes (TextEncoder is available in the RN Hermes runtime and in Node). */
export declare function utf8ToBytes(text: string): Uint8Array;
/** Decode UTF-8 bytes to a string. */
export declare function bytesToUtf8(bytes: Uint8Array): string;
/** Accept either raw bytes or a UTF-8 string and return bytes. Used by the message/body helpers. */
export declare function asBytes(value: Uint8Array | string): Uint8Array;
