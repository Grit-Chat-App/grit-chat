import { HopRelayPool } from "./types";
export interface NativeStatus {
    relayed: number;
    delivered: boolean;
    forwardHops: number;
    forwardMs: number;
}
/** A topic row as `hpsMyTopics` puts it on the wire: addresses base58, enums lowercase strings.
 *
 *  `kind` and `access` are typed as plain strings here, like `linkUp`'s `role`, because that is
 *  honestly what crosses an RN bridge: an arbitrary string the native side chose. node.ts narrows
 *  them to the public unions without rewriting an unrecognized value, so a garbage access mode fails
 *  every comparison instead of reading as `open`. */
export interface NativeHpsTopic {
    host: string;
    path: string;
    kind: string;
    hosting: boolean;
    access: string;
}
/** A discoverable topic descriptor as `hpsBrowse` puts it on the wire. */
export interface NativeHpsTopicInfo {
    host: string;
    path: string;
    kind: string;
    title: string;
    summary: string;
    access: string;
}
export interface HopNativeModule {
    createEphemeral(): Promise<number>;
    createWithSecret(secretB64: string): Promise<number>;
    openPersistent(dbPath: string, secretB64: string, appSecretB64: string): Promise<number>;
    openKeyed(dbPath: string, keyB64: string, secretB64: string, appSecretB64: string): Promise<number>;
    closeNode(handle: number): Promise<void>;
    address(handle: number): Promise<string>;
    secret(handle: number): Promise<string>;
    setName(handle: number, name: string): Promise<void>;
    subscribe(handle: number, topic: string): Promise<void>;
    publishPrekey(handle: number): Promise<boolean>;
    tick(handle: number, nowMs: number): Promise<void>;
    isPersistent(handle: number): Promise<boolean>;
    rehydrateDropped(handle: number): Promise<number>;
    isSecured(handle: number, addrB58: string): Promise<boolean>;
    send(handle: number, toB58: string, contentType: string, bodyB64: string, requestAck: boolean): Promise<string | null>;
    sendTo(handle: number, toB58: string, contentType: string, bodyB64: string, requestAck: boolean): Promise<string | null>;
    status(handle: number, idB64: string): Promise<NativeStatus>;
    acceptInbox(handle: number, idB64: string): Promise<boolean>;
    sendServiceRequest(handle: number, toB58: string, service: string, method: string, argsB64: string): Promise<string | null>;
    sendServiceResponse(handle: number, toB58: string, forRequestIdB64: string, status: number, bodyB64: string): Promise<boolean>;
    acceptServiceResponse(handle: number, forRequestIdB64: string): Promise<boolean>;
    startPump(handle: number, intervalMs: number): Promise<void>;
    stopPump(handle: number): Promise<void>;
    linkUp(handle: number, link: number, role: string): Promise<void>;
    linkDown(handle: number, link: number): Promise<void>;
    bytesReceived(handle: number, link: number, bytesB64: string): Promise<void>;
    relayAdd(handle: number, url: string, configured: boolean): Promise<boolean>;
    relayNext(handle: number): Promise<string | null>;
    relayReport(handle: number, url: string, ok: boolean): Promise<void>;
    relayPool(handle: number): Promise<HopRelayPool>;
    hpsRegister(handle: number, path: string, kind: string, access: string, visibility: string): Promise<string | null>;
    hpsSubscribe(handle: number, hostB58: string, path: string): Promise<string | null>;
    hpsPublish(handle: number, path: string, bodyB64: string): Promise<string | null>;
    acceptHpsMessage(handle: number, idB64: string): Promise<boolean>;
    hpsInvite(handle: number, path: string, destB58: string): Promise<string | null>;
    hpsAcceptInvite(handle: number, hostB58: string, path: string): Promise<string | null>;
    hpsDeclineInvite(handle: number, hostB58: string, path: string): Promise<boolean>;
    hpsLeave(handle: number, path: string): Promise<boolean>;
    hpsPending(handle: number, path: string): Promise<string[]>;
    hpsApprove(handle: number, path: string, requesterB58: string): Promise<string | null>;
    hpsDeny(handle: number, path: string, requesterB58: string): Promise<boolean>;
    hpsRekey(handle: number, path: string, newPath: string, removeB58: string[]): Promise<string[]>;
    hpsReach(handle: number, path: string): Promise<number>;
    hpsMembers(handle: number, path: string): Promise<string[]>;
    hpsMyTopics(handle: number): Promise<NativeHpsTopic[]>;
    hpsBrowse(handle: number): Promise<NativeHpsTopicInfo[]>;
    addressToBase58(bytesB64: string): Promise<string>;
    addressFromBase58(text: string): Promise<string | null>;
    addListener(eventType: string): void;
    removeListeners(count: number): void;
}
/** Event names the native pump emits over the NativeEventEmitter. */
export declare const HopEvent: {
    readonly Message: "HopMesh:message";
    readonly ServiceRequest: "HopMesh:serviceRequest";
    readonly ServiceResponse: "HopMesh:serviceResponse";
    readonly Outgoing: "HopMesh:outgoing";
    readonly HpsMessage: "HopMesh:hpsMessage";
    readonly HpsInvite: "HopMesh:hpsInvite";
};
/** Resolve the linked native module, throwing a clear error if the app was not rebuilt. */
export declare function getHopNative(): HopNativeModule;
/** Resolve a NativeEventEmitter bound to the HopMesh module. */
export declare function getHopEmitter(): {
    addListener(event: string, cb: (payload: any) => void): {
        remove(): void;
    };
};
/** Test seam: inject a fake native module + emitter (used by the unit tests). */
export declare function __setHopNativeForTesting(mod: HopNativeModule | null, emitter?: any): void;
