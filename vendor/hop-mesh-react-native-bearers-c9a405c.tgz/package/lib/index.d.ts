import { HopNode } from "./node";
import { HopOpenOptions } from "./types";
/** Factory for `HopNode`s, plus the base58 address helpers. */
export declare const Hop: {
    /** A fresh identity with ephemeral (in-memory) storage. */
    ephemeral(): Promise<HopNode>;
    /** Restore from a saved 32-byte identity secret (empty = fresh) with ephemeral storage. */
    withSecret(secret: Uint8Array): Promise<HopNode>;
    /**
     * Open with persistent storage. Resolves null only when the db path is unusable.
     * Pass `key` (a raw 32-byte keystore key) to encrypt the store at rest (SQLCipher).
     */
    open(opts: HopOpenOptions): Promise<HopNode | null>;
};
/** base58 address helpers, mirroring the native `HopAddress`. */
export declare const HopAddress: {
    /** Encode a 32-byte address as base58. */
    toBase58(bytes: Uint8Array): Promise<string>;
    /** Decode a base58 address string, or null if it is not exactly a 32-byte address. */
    fromBase58(text: string): Promise<Uint8Array | null>;
};
export { HopNode } from "./node";
export type { Emitter, Subscription } from "./node";
export { toBase64, fromBase64, utf8ToBytes, bytesToUtf8, asBytes, } from "./base64";
export type { HopMessage, HopStatus, HopServiceRequest, HopServiceResponse, HopOpenOptions, HopSendOptions, HopRelayPool, HpsKind, HpsAccess, HpsVisibility, HopHpsMessage, HopHpsInvite, HopHpsTopic, HopHpsTopicInfo, } from "./types";
export type { HopNativeModule } from "./native";
