/** Encode raw bytes as a standard (padded) base64 string. */
export declare function toBase64(bytes: Uint8Array): string;
/** Decode a base64 string back to raw bytes. Rejects characters outside the alphabet. */
export declare function fromBase64(text: string): Uint8Array;
/** Encode a string as UTF-8 bytes. Lone surrogates encode as U+FFFD, matching `TextEncoder`. */
export declare function utf8ToBytes(text: string): Uint8Array;
/**
 * Decode UTF-8 bytes to a string. TOTAL: never throws. Malformed input yields U+FFFD replacement
 * characters exactly where a WHATWG decoder puts them, because this runs inside the accept path of
 * inbound messages, where a throw silently stalls delivery instead of surfacing.
 *
 * Rejects, as replacement characters, everything the spec calls malformed: overlong encodings,
 * surrogate code points, values above U+10FFFF, stray or missing continuation bytes. On a bad
 * sequence it emits one U+FFFD for the maximal valid subpart and re-examines the offending byte,
 * so a truncated sequence followed by good data does not swallow the good data.
 */
export declare function bytesToUtf8(bytes: Uint8Array): string;
/** Accept either raw bytes or a UTF-8 string and return bytes. Used by the message/body helpers. */
export declare function asBytes(value: Uint8Array | string): Uint8Array;
