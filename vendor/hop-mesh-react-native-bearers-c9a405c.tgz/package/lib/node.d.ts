import { HopNativeModule } from "./native";
import { HopBearer, HopBearerSnapshot, HopHpsInvite, HopHpsMessage, HopHpsTopic, HopHpsTopicInfo, HopMessage, HopRelayPool, HopSendOptions, HopServiceRequest, HopServiceResponse, HopStatus, HpsAccess, HpsKind, HpsVisibility } from "./types";
export interface Emitter {
    addListener(event: string, cb: (payload: any) => void): {
        remove(): void;
    };
}
/** An unsubscribe handle returned by the `on*` methods. */
export interface Subscription {
    remove(): void;
}
/** A core packet emitted for a link owned by the JavaScript host. */
export interface HopOutgoing {
    readonly link: number;
    readonly bytes: Uint8Array;
}
/**
 * A running Hop node. Owns the native HopNode, HopRuntime, and bearer manager for this process. Call
 * `close()` when done before opening another node.
 *
 * The core is poll-model: nothing is pushed asynchronously until you `start()` the pump. The native
 * runtime ticks the clock, drains outgoing packets, and routes them through its native bearers before
 * polling the inbox, hops:// queues and hps:// queues. Inbox items, responses and hps:// publications
 * repeat on every poll until you `acceptInbox` / `acceptServiceResponse` / `acceptHpsMessage` them.
 * hps:// INVITES are the exception: the pump takes and clears them, so a drained invite is gone and a
 * host must persist what it surfaces.
 */
export declare class HopNode {
    private readonly native;
    private readonly emitter;
    /** The opaque native handle. Exposed for advanced interop; treat as read-only. */
    readonly handle: number;
    constructor(native: HopNativeModule, emitter: Emitter, 
    /** The opaque native handle. Exposed for advanced interop; treat as read-only. */
    handle: number);
    /** This node's address, base58-encoded. */
    address(): Promise<string>;
    /** This node's 32-byte identity secret; persist it to restore the node later. */
    secret(): Promise<Uint8Array>;
    /** Set the display name reported via presence / hop.identify. */
    setName(name: string): Promise<void>;
    /** Subscribe to an hps:// topic. */
    subscribe(topic: string): Promise<void>;
    /** Publish a fresh prekey bundle to the directory. */
    publishPrekey(): Promise<boolean>;
    /** Advance the node clock. The pump calls this for you; only needed for manual driving. */
    tick(nowMs?: number): Promise<void>;
    /** False means the db path was unusable and the node is running ephemerally (state won't survive). */
    isPersistent(): Promise<boolean>;
    /** How many persisted records failed to decode on startup; non-zero means state lost on upgrade. */
    rehydrateDropped(): Promise<number>;
    /** Whether we hold a forward-secret session with `addr` (content is ratcheted, not static-sealed). */
    isSecured(addr: string): Promise<boolean>;
    /** Mark a host-owned transport link up. Native bearers retain ownership of their own links. */
    linkUp(link: number, role: "dialer" | "acceptor"): Promise<void>;
    /** Feed a received host-owned transport frame into the Hop core. */
    bytesReceived(link: number, bytes: Uint8Array): Promise<void>;
    /** Mark a host-owned transport link down. */
    linkDown(link: number): Promise<void>;
    /** Receive packets the core needs the host-owned transport to carry. */
    onOutgoing(cb: (packet: HopOutgoing) => void): Subscription;
    /** Send an untraceable (section 39) message. Resolves the 32-byte bundle id, or null on error. */
    send(opts: HopSendOptions): Promise<Uint8Array | null>;
    /** Send to a directly-connected peer (the directed section 27 path). Resolves the bundle id, or null. */
    sendTo(opts: HopSendOptions): Promise<Uint8Array | null>;
    /** Delivery status of a message we sent, by its bundle id. */
    status(id: Uint8Array): Promise<HopStatus>;
    /** Durably accept one inbox item (by its id) so it stops repeating on the next poll. */
    acceptInbox(id: Uint8Array): Promise<boolean>;
    /** Send an hops:// service request. Resolves the request id, or null on error. */
    sendServiceRequest(args: {
        to: string;
        service: string;
        method: string;
        args: Uint8Array | string;
    }): Promise<Uint8Array | null>;
    /** Reply to an hops:// service request. */
    sendServiceResponse(args: {
        to: string;
        forRequestId: Uint8Array;
        status: number;
        body: Uint8Array | string;
    }): Promise<boolean>;
    /** Durably accept a previously-polled response by its 32-byte correlation request id. */
    acceptServiceResponse(forRequestId: Uint8Array): Promise<boolean>;
    /**
     * Read every bearer's authoritative state in one revisioned snapshot.
     *
     * BLE and LAN are native bearer AAR/pod dependencies. Relay is deliberately outside this
     * cross-platform bridge and remains disabled in this state shape.
     */
    bearerSnapshot(): Promise<HopBearerSnapshot>;
    /**
     * Enable or disable one native bearer without affecting the others.
     *
     * Disabling closes its live native links before this resolves. Enabling relay rejects because this
     * bridge does not own a relay bearer.
     */
    setBearerEnabled(bearer: HopBearer, enabled: boolean): Promise<HopBearerSnapshot>;
    /**
     * Offer a relay endpoint to the pool. Resolves true if the endpoint is now pooled.
     *
     * `configured` marks an operator or user choice, which a gossiped endpoint can never demote, and it
     * defaults to true here because a URL an app hands in came from a person or a build, not the mesh.
     */
    relayAdd(url: string, configured?: boolean): Promise<boolean>;
    /**
     * The relay to dial right now, or null when there is nothing dialable.
     *
     * null with a non-zero `relayPool().total` is the degraded "every candidate is backed off" state. A
     * UI must show it as that and retry, NOT as offline: the pool still knows where to retry, and the
     * backoff always eventually recovers. null with a zero total is an empty pool, which is the case
     * `relayAdd` fixes.
     */
    relayNext(): Promise<string | null>;
    /** Report a dial outcome so the pool can score it. A success clears that endpoint's failure history;
     *  failures back it off exponentially and always eventually recover. */
    relayReport(url: string, ok: boolean): Promise<void>;
    /** Pooled endpoint counts: total known, and how many are dialable right now. */
    relayPool(): Promise<HopRelayPool>;
    /**
     * Host a topic at `path`. The node mints its keys and persists them, so the topic survives restarts.
     *
     * Resolves the service public key subscribers verify broadcasts with. That key is EMPTY for a
     * channel, which has no service signing key because every member writes under their own identity, so
     * an empty result is a success. Failure is null, and the two are deliberately distinguishable.
     *
     * Access and visibility are mandatory: they decide who receives the topic key, so this public API
     * never invents a policy when a caller omitted one.
     */
    hpsRegister(path: string, kind: HpsKind, access: HpsAccess, visibility: HpsVisibility): Promise<Uint8Array | null>;
    /** Subscribe to `hps://{host}/{path}`: ask the host for the topic's keys. Resolves the request's
     *  bundle id, or null. Whether the keys arrive at all is the access mode's call, not this one's. */
    hpsSubscribe(host: string, path: string): Promise<Uint8Array | null>;
    /** Publish to a topic we host, or (for a channel) belong to. Resolves the bundle id, or null. */
    hpsPublish(path: string, body: Uint8Array | string): Promise<Uint8Array | null>;
    /**
     * Durably accept one hps:// publication (by its id) so it stops repeating on the next poll.
     *
     * The pump polls with the NON-accepting poll, exactly as it does the inbox: a publication stays
     * queued until JS accepts it, so one that arrives while the JS side crashes is redelivered rather
     * than lost. Accept it once your own store holds it.
     */
    acceptHpsMessage(id: Uint8Array): Promise<boolean>;
    /** Host to contact: invite an address to a topic we host (the `invite` access mode). Resolves the
     *  invite's bundle id, or null. */
    hpsInvite(path: string, dest: string): Promise<Uint8Array | null>;
    /** Accept an invite we received: joins the topic once the host seals us the keys. */
    hpsAcceptInvite(host: string, path: string): Promise<Uint8Array | null>;
    /** Decline an invite. Durable, so the host does not re-offer it. */
    hpsDeclineInvite(host: string, path: string): Promise<boolean>;
    /**
     * Leave a topic we follow, or retire one we host.
     *
     * The native call also yields the leave bundle's id; this narrows to the ok flag on purpose, because
     * an RN client has nothing to do with that id (there is no hps status query to correlate it against).
     */
    hpsLeave(path: string): Promise<boolean>;
    /** Host: the addresses waiting for approval on a `requestToJoin` topic, base58-encoded. */
    hpsPending(path: string): Promise<string[]>;
    /** Host: approve a pending requester, which is what hands them the content key. Resolves the
     *  handoff's bundle id, or null. */
    hpsApprove(path: string, requester: string): Promise<Uint8Array | null>;
    /** Host: deny a pending requester. No key is handed out. */
    hpsDeny(path: string, requester: string): Promise<boolean>;
    /**
     * Host: rotate the topic's content key, optionally onto `newPath`, withholding it from `remove`.
     *
     * This is what revocation is here: a removed address keeps whatever it already read and can decrypt
     * nothing published after the rotation. Resolves one bundle id per member the new key was sealed to.
     */
    hpsRekey(path: string, newPath?: string, remove?: string[]): Promise<Uint8Array[]>;
    /** Host: how many distinct members have acked a publication on this topic. An Open topic keeps no
     *  member list, so an ack is the only moment it learns a member's address at all. */
    hpsReach(path: string): Promise<number>;
    /** Host: the retained member set for this topic, base58-encoded. */
    hpsMembers(path: string): Promise<string[]>;
    /** Every topic this node hosts or follows, read from the node's own store. Use it to rebuild a topic
     *  list at startup rather than persisting one yourself. */
    hpsMyTopics(): Promise<HopHpsTopic[]>;
    /** Discoverable topics found on the mesh: decrypted descriptors, not subscriptions. Only topics
     *  hosted by apps holding the same app secret are ever surfaced (section 17). */
    hpsBrowse(): Promise<HopHpsTopicInfo[]>;
    /** Start the native runtime pump: it ticks the node, routes packets through native bearers, and polls
     *  the inbox / hops:// / hps:// queues on an interval. */
    start(intervalMs?: number): Promise<void>;
    /** Stop the pump. Events stop until `start()` is called again. */
    stop(): Promise<void>;
    private subscribe$;
    /** Subscribe to inbound messages. Returns an unsubscribe handle. */
    onMessage(cb: (message: HopMessage) => void): Subscription;
    /** Subscribe to inbound hops:// service requests (this node acting as a service). */
    onServiceRequest(cb: (request: HopServiceRequest) => void): Subscription;
    /** Subscribe to inbound hops:// service responses (this node acting as a caller). */
    onServiceResponse(cb: (response: HopServiceResponse) => void): Subscription;
    /**
     * Subscribe to complete bearer snapshots. A callback always receives BLE, LAN, and relay together,
     * ordered by a revision the native runtime increases whenever any state changes.
     */
    onBearerState(cb: (snapshot: HopBearerSnapshot) => void): Subscription;
    /** Subscribe to inbound hps:// publications on topics this node hosts or follows. Each repeats on
     *  every poll until `acceptHpsMessage`. */
    onHpsMessage(cb: (message: HopHpsMessage) => void): Subscription;
    /** Subscribe to inbound hps:// invites. Take-and-clear, not accept-to-remove: the native queue drops
     *  an invite as it is emitted, so persist what this hands you or it is gone. */
    onHpsInvite(cb: (invite: HopHpsInvite) => void): Subscription;
    /** Free the native node. Idempotent. */
    close(): Promise<void>;
}
